/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package martinezaquino.leongabriel.pp.progii125;

/**
 *
 * @author estudio
 */
public class Flor extends Planta{
    private TemporadaFlorecimiento temporadaFlorecimiento;
            
    public Flor(String nombre, String ubicacion, String clima, TemporadaFlorecimiento temporadaFlorecimiento) {
        super(nombre, ubicacion, clima);
        this.temporadaFlorecimiento = temporadaFlorecimiento;
    }
    
    @Override
    public void podarPlanta() {
         System.out.println("No se pueden podar las flores");
    }
    
    @Override
    public String toString() {        
        return super.toString() + "Temporada de florecimiento: " + temporadaFlorecimiento;
    }
    
    
}
