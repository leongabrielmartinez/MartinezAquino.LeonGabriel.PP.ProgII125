
package martinezaquino.leongabriel.pp.progii125;


public class PlantaDuplicadaExcepcion extends RuntimeException{

    public final static String MESSAGE = "La planta que intenta agregar ya existe"; 

    public PlantaDuplicadaExcepcion() {
        super(MESSAGE);
    }
    
}
