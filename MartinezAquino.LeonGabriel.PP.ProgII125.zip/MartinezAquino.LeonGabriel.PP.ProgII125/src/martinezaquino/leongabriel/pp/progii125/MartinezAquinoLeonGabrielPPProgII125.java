
package martinezaquino.leongabriel.pp.progii125;

public class MartinezAquinoLeonGabrielPPProgII125 {

    
    public static void main(String[] args) {
        JardinBotanico jardin = new JardinBotanico();
        
        try {          
        jardin.agregarPlanta(new Arbol("Roble", "Zona norte del jardin", "Calido", 10));
        jardin.agregarPlanta(new Arbol("Roble", "Zona norte del jardin", "Calido", 10));
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
        }
        
        try {          
        jardin.agregarPlanta(new Arbol("Roble", "Zona sur del jardin", "Calido", 15));
        jardin.agregarPlanta(new Arbusto("Arbusto", "Zona sur del jardin", "Calido", 5));
        jardin.agregarPlanta(new Flor("Flor", "Zona oeste del jardin", "Templado", TemporadaFlorecimiento.VERANO));
        } catch (RuntimeException e) {
            System.out.println(e.getMessage());
        }
        
        jardin.mostrarPlantas();
        
        jardin.podarPlantas();
        
        
        

    }
    
}
