
package martinezaquino.leongabriel.pp.progii125;


public class Arbusto extends Planta{
    private int densidadFollaje;
    private static final int MAX_DENSIDAD = 10;
    private static final int MIN_DENSIDAD = 1;

    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        if(!validarDensiadadDelFollaje(densidadFollaje)){
            throw new IllegalArgumentException("El follaje debe ser mayor a 1 y menor a 10");
        }        
        this.densidadFollaje = densidadFollaje;
    }

    private boolean validarDensiadadDelFollaje(int densidadFollaje){
        return densidadFollaje >= MIN_DENSIDAD && densidadFollaje <= MAX_DENSIDAD; 
    }
    
    @Override
    public void podarPlanta() {
         System.out.println("Se esta podando el arbusto");
    }

    @Override
    public String toString() {        
        return super.toString() + "Densidad del follaje: " + densidadFollaje ;
    }

    
}

