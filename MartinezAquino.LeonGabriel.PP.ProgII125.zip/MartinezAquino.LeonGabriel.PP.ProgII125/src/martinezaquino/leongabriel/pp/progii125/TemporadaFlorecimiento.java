
package martinezaquino.leongabriel.pp.progii125;


public enum TemporadaFlorecimiento {
    PRIMAVERA, 
    VERANO, 
    OTOÑO, 
    INVIERNO
}
