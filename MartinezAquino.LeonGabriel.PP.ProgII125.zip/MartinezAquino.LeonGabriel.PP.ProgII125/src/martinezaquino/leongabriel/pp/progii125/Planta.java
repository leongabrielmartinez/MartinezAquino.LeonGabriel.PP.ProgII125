
package martinezaquino.leongabriel.pp.progii125;

public abstract class Planta {
    private String nombre;
    private String ubicacion;
    private String clima;

    public Planta(String nombre, String ubicacion, String clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }
    
    public abstract void podarPlanta();

    @Override
    public boolean equals(Object obj) {
        if (this == obj){
            return true;
	}
	if (obj == null){
            return false;
	}
	if (obj instanceof Planta p){
            return nombre.equals(p.nombre) && ubicacion.equals(p.ubicacion);
	}

	return false;
    }

    @Override
    public String toString() {
        return String.format("""
                        ------------------------------
                                    %s
                        ------------------------------
                        Ubicacion: %s 
                        Clima: %s
                        """,
                nombre, ubicacion, clima);
    }
    
    
    
    
    
    
    
}
