
package martinezaquino.leongabriel.pp.progii125;


public class Arbol extends Planta{

    private int alturaMaxima;
    
    public Arbol(String nombre, String ubicacion, String clima, int alturaMaxima) {
        super(nombre, ubicacion, clima);
        validarNumeroPositivo(alturaMaxima);
        this.alturaMaxima = alturaMaxima;
    }
    

    @Override
    public void podarPlanta() {
        System.out.println("Se esta podando el arbol");
    }
    
    private void validarNumeroPositivo(int numero){
        if(numero < 1){
            throw new IllegalArgumentException();
        }
    }

    @Override
    public String toString() {        
        return super.toString() + "Altura Maxima: " + alturaMaxima ;
    }
    
    


    
    
}
