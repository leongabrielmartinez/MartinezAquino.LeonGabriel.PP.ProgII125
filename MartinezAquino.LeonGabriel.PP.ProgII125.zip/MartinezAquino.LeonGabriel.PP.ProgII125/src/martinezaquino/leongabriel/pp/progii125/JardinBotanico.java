
package martinezaquino.leongabriel.pp.progii125;

import java.util.ArrayList;
import java.util.List;


public class JardinBotanico {
    private List<Planta> plantas = new ArrayList<>();
        
    public void agregarPlanta(Planta p)
    {
        if(p == null){                
            throw new NullPointerException("se esta intentando agregar un objeto nulo");
        }
        
        if(plantas.contains(p)){
            throw new PlantaDuplicadaExcepcion();
        }
        
        plantas.add(p);
    }
    
    public void mostrarPlantas(){
        for(Planta p: plantas){
            System.out.println(p);
        }
    }

    public void podarPlantas(){
        for(Planta p: plantas){
            p.podarPlanta();
        }
    }

      
    
}
